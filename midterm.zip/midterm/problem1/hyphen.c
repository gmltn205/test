#include <stdio.h>
#include <stdlib.h>

int main (int argc, char ** argv)
{
	char c ;
	while ((c = fgetc(stdin)) != EOF) {
		printf("%c-", c) ;
	}
	printf("\n") ;

	return EXIT_SUCCESS ;
}
